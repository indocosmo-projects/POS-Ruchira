DELETE FROM choices WHERE id=102;
insert into choices(id,code,name,description,is_global,created_by,created_at,updated_by,updated_at,is_system,is_deleted) values ("102","A001","Choice2","test","1","0","2020-06-13 10:10:51.0",null,null,"0","0");
