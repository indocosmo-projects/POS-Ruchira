update stock_items set is_deleted=1 where id =101000481;
update sale_items set is_deleted=1 where id =101000481;
update stock_items set is_deleted=1 where id =101000218;
update sale_items set is_deleted=1 where id =101000218;
