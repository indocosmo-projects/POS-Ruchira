update stock_items set is_deleted=1 where id =102000223;
update sale_items set is_deleted=1 where id =102000223;
update stock_items set is_deleted=1 where id =102000201;
update sale_items set is_deleted=1 where id =102000201;
update stock_items set is_deleted=1 where id =102000194;
update sale_items set is_deleted=1 where id =102000194;
update stock_items set is_deleted=1 where id =102000190;
update sale_items set is_deleted=1 where id =102000190;
