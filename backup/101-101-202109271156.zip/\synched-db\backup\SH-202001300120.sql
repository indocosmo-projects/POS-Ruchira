DELETE FROM uoms WHERE id=101000101;
insert into uoms(id,code,name,description,is_compound,base_uom_id,compound_unit,uom_symbol,decimal_places,created_by,created_at,updated_by,updated_at,is_deleted,is_system) values ("101000101","LTR","Liter",null,null,null,null,"Ltr","3","0","2020-01-30 11:48:55.0",null,null,"0","0");
