DELETE FROM uoms WHERE id=101000103;
insert into uoms(id,code,name,description,is_compound,base_uom_id,compound_unit,uom_symbol,decimal_places,created_by,created_at,updated_by,updated_at,is_deleted,is_system) values ("101000103","GLASS","GLASS",null,"1","101000102","3.00000","gl","0","0","2020-01-30 07:54:32.0",null,null,"0","0");
