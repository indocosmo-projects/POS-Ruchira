DELETE FROM sale_item_display_order WHERE id=101000552;
insert into sale_item_display_order(id,menu_id,sub_class_id,sale_item_id,display_order,is_deleted) values ("101000552","101000101","111","177","1","0");
DELETE FROM sale_item_display_order WHERE id=101000553;
insert into sale_item_display_order(id,menu_id,sub_class_id,sale_item_id,display_order,is_deleted) values ("101000553","101000101","111","214","2","0");
DELETE FROM sale_item_display_order WHERE id=101000554;
insert into sale_item_display_order(id,menu_id,sub_class_id,sale_item_id,display_order,is_deleted) values ("101000554","101000101","111","102000156","3","0");
DELETE FROM sale_item_display_order WHERE id=101000555;
insert into sale_item_display_order(id,menu_id,sub_class_id,sale_item_id,display_order,is_deleted) values ("101000555","101000101","111","102000186","4","0");
