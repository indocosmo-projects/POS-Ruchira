DELETE FROM uoms WHERE id=101000105;
insert into uoms(id,code,name,description,is_compound,base_uom_id,compound_unit,uom_symbol,decimal_places,created_by,created_at,updated_by,updated_at,is_deleted,is_system) values ("101000105","BTL1LTR","Bottle  1 ltr",null,"1","24","1000.00000","1B","2","0","2020-02-01 05:02:34.0","0","2020-02-01 05:28:11.0","0","0");
