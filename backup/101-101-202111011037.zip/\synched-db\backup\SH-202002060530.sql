DELETE FROM mrp_item_category WHERE id=101000343;
insert into mrp_item_category(id,parent_id,code,name,description,is_system,is_deleted,created_by,created_at,updated_by,updated_at) values ("101000343",null,"HKKHKKK","khhhhhh","","0","0","0","2020-02-06 03:59:18.0",null,null);
