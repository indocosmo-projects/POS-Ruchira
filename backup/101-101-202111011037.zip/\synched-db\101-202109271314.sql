DELETE FROM kitchens WHERE id=101000102;
insert into kitchens(id,code,name,description,printer_name,printer_port,created_by,created_at,updated_by,updated_at,is_deleted,is_system,last_sync_at) values ("101000102","K2","Kitchen 2 ","",null,null,"0","2021-09-27 01:13:41.0",null,null,"0","0","2021-09-27 13:13:41.0");
