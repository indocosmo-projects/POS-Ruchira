DELETE FROM stations WHERE id=101000101;
insert into stations(id,code,name,description,type,created_by,created_at,updated_by,updated_at,is_deleted,is_system,last_sync_at) values ("101000101","TER01","Terminal 1","","2","0","2019-10-01 01:20:57.0",null,null,"0","0","2019-10-01 01:20:57.0");
DELETE FROM stations WHERE id=101000102;
insert into stations(id,code,name,description,type,created_by,created_at,updated_by,updated_at,is_deleted,is_system,last_sync_at) values ("101000102","TER02","Terminal 2","","2","0","2019-10-01 01:21:24.0",null,null,"0","0","2019-10-01 01:21:24.0");
DELETE FROM stations WHERE id=101000103;
insert into stations(id,code,name,description,type,created_by,created_at,updated_by,updated_at,is_deleted,is_system,last_sync_at) values ("101000103","TER03","Terminal 3","","2","0","2019-10-01 01:21:48.0",null,null,"0","0","2019-10-01 01:21:48.0");
DELETE FROM stations WHERE id=101000104;
insert into stations(id,code,name,description,type,created_by,created_at,updated_by,updated_at,is_deleted,is_system,last_sync_at) values ("101000104","PMT01","Payment Ter.1","","2","0","2019-10-01 01:22:07.0",null,null,"0","0","2019-10-01 01:22:07.0");
