DELETE FROM uoms WHERE id=101000102;
insert into uoms(id,code,name,description,is_compound,base_uom_id,compound_unit,uom_symbol,decimal_places,created_by,created_at,updated_by,updated_at,is_deleted,is_system) values ("101000102","PEG60","PEG60",null,"1","24","60.00000","p60","2","0","2020-01-30 07:53:03.0",null,null,"0","0");
