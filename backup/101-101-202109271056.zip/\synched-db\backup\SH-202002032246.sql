DELETE FROM uoms WHERE id=101000108;
insert into uoms(id,code,name,description,is_compound,base_uom_id,compound_unit,uom_symbol,decimal_places,created_by,created_at,updated_by,updated_at,is_deleted,is_system) values ("101000108","BT750","Bottle 750",null,"1","24","750.00000","btl","2","0","2020-02-04 09:15:46.0",null,null,"0","0");
