DELETE FROM voucher_types WHERE id=101000102;
insert into voucher_types(id,code,name,description,voucher_type,value,is_overridable,is_change_payable,account_code,is_valid,created_by,created_at,updated_by,updated_at,is_deleted,is_system) values ("101000102","V0002","Gift Voucher 500","","101000101","500.00000","0","0","0","1","0","2020-09-23 04:27:31.0",null,null,"0","0");
