DELETE FROM uoms WHERE id=101000104;
insert into uoms(id,code,name,description,is_compound,base_uom_id,compound_unit,uom_symbol,decimal_places,created_by,created_at,updated_by,updated_at,is_deleted,is_system) values ("101000104","CASE12","CASE12",null,"1","8","12.00000","BTL","1","0","2020-01-30 08:05:38.0",null,null,"0","0");
