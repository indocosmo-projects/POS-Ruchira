update customers set is_deleted=1 where id =0;
