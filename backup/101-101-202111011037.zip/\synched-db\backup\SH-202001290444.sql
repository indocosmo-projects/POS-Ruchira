DELETE FROM mrp_item_category WHERE id=101000101;
insert into mrp_item_category(id,parent_id,code,name,description,is_system,is_deleted,created_by,created_at,updated_by,updated_at) values ("101000101",null,"001","Alcoholic","","0","0","0","2020-01-29 03:13:35.0",null,null);
