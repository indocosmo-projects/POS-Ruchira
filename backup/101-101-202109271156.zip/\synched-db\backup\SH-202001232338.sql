DELETE FROM stations WHERE id=101000101;
insert into stations(id,code,name,description,type,created_by,created_at,updated_by,updated_at,is_deleted,is_system,last_sync_at) values ("101000101","PYTM","PYTM","","2","0","2020-01-24 10:07:36.0",null,null,"0","0","2020-01-23 23:37:36.0");
DELETE FROM stations WHERE id=101000102;
insert into stations(id,code,name,description,type,created_by,created_at,updated_by,updated_at,is_deleted,is_system,last_sync_at) values ("101000102","KOT","KOT","","3","0","2020-01-24 10:07:51.0",null,null,"0","0","2020-01-23 23:37:51.0");
