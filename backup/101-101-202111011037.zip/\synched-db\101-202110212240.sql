DELETE FROM voucher_types WHERE id=101000101;
insert into voucher_types(id,code,name,description,voucher_type,value,is_overridable,is_change_payable,account_code,is_valid,created_by,created_at,updated_by,updated_at,is_deleted,is_system) values ("101000101","J","j","","0","8.00000","0","1","7","1","0","2021-10-21 10:40:00.0",null,null,"0","0");
DELETE FROM voucher_types WHERE id=101000102;
insert into voucher_types(id,code,name,description,voucher_type,value,is_overridable,is_change_payable,account_code,is_valid,created_by,created_at,updated_by,updated_at,is_deleted,is_system) values ("101000102","V01","v09","","0","250.00000","0","1","1","1","0","2021-10-21 10:40:26.0",null,null,"0","0");
