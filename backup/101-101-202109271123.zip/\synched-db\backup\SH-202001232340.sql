DELETE FROM kitchens WHERE id=101000101;
insert into kitchens(id,code,name,description,printer_name,printer_port,created_by,created_at,updated_by,updated_at,is_deleted,is_system,last_sync_at) values ("101000101","KOT","KOT","",null,null,"0","2020-01-24 10:09:09.0",null,null,"0","0","2020-01-23 23:39:09.0");
DELETE FROM kitchens WHERE id=101000102;
insert into kitchens(id,code,name,description,printer_name,printer_port,created_by,created_at,updated_by,updated_at,is_deleted,is_system,last_sync_at) values ("101000102","BOT","BOT","",null,null,"0","2020-01-24 10:09:19.0",null,null,"0","0","2020-01-23 23:39:19.0");
