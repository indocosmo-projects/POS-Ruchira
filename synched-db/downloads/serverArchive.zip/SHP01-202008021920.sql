update stock_items set is_deleted=1 where id =102000169;
update sale_items set is_deleted=1 where id =102000169;
update stock_items set is_deleted=1 where id =102000168;
update sale_items set is_deleted=1 where id =102000168;
update stock_items set is_deleted=1 where id =102000159;
update sale_items set is_deleted=1 where id =102000159;
update stock_items set is_deleted=1 where id =102000156;
update sale_items set is_deleted=1 where id =102000156;
