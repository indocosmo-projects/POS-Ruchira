DELETE FROM rounding WHERE id=101000102;
insert into rounding(id,code,name,description,round_to,created_by,created_at,updated_by,updated_at,is_deleted,is_system) values ("101000102","R50","Round Off 50","","0.50000","0","2020-07-16 08:31:47.0",null,null,"0","0");
