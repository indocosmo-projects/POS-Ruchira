DELETE FROM uoms WHERE id=101000106;
insert into uoms(id,code,name,description,is_compound,base_uom_id,compound_unit,uom_symbol,decimal_places,created_by,created_at,updated_by,updated_at,is_deleted,is_system) values ("101000106","CASE24","Case 24 nos",null,"1","8","24.00000","cs","2","0","2020-02-04 08:59:18.0",null,null,"0","0");
